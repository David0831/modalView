//
//  CollectionViewCell.swift
//  Trabajo01
//
//  Created by David Alejandro Garcia Cortes on 12/05/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
